# smart_car
Dedicated program of Arduino bluetooth smart car kit from Devicemart
